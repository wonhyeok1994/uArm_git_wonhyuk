#include <string>
#include <ros/ros.h>
#include <ros/console.h>
#include <opencv2/opencv.hpp>
#include <math.h>
#include <std_msgs/String.h>
#include <std_msgs/Empty.h>
#include <swiftpro/status.h>


#define LEFT	290
#define TOP		290
#define RIGHT	320
#define BOTTOM	320

using namespace cv;

VideoCapture cap;
swiftpro::status status;
int flag = 0;
int ok = 0;

void camera_box_callback(const swiftpro::status& msg)
{
	Mat img, img_gray;
	Mat img_file, img_file_gray, img_file_resize;
	Mat img_box, img_box_thre, img_box_color;

	//img_file = imread("/home/yay/catkin_ws/src/RosForSwiftAndSwiftPro/swiftpro/img/img_file1.PNG");

    cap.read(img_file);

	resize(img_file, img_file_resize, Size(640, 480));

    std::cout << msg.status << std::endl;
	
	while (1)
	{

		cap.read(img);			//img.size() 640x480

		if (img.empty()) {
			printf("이미지 안 불러와져 img");
			break;
		}

        if (img_file.empty()) {
			printf("이미지 안 불러와져 img_file");
			break;
		}

        //std::cout << img_file.size() << std::endl;

		cvtColor(img, img_gray, COLOR_BGR2GRAY);
		cvtColor(img_file_resize, img_file_gray, COLOR_BGR2GRAY);
		absdiff(img_file_gray, img_gray, img_box);				
		threshold(img_box, img_box_thre, 15, 255, THRESH_BINARY);

		cvtColor(img_box_thre, img_box_color, COLOR_GRAY2BGR);
		bitwise_and(img, img_box_color, img_box_color);

		Mat img_box_color_ROI, img_box_color_copy;
		img_box_color.copyTo(img_box_color_copy);
		
		img_box_color_ROI = img_box_color_copy(Rect_<float>(Point2f(LEFT + 1, TOP - 1), Point2f(RIGHT + 1, BOTTOM - 1)));		

		circle(img, Point(LEFT, TOP), 3, Scalar(255, 0, 0), 3);
		circle(img, Point(RIGHT, BOTTOM), 3, Scalar(255,0,0), 3);
		
		//int check = 0;		//물체가 잇나?

		for (int j = 0; j < img_box_color_ROI.rows; j++)
		{
			for (int i = 0; i < img_box_color_ROI.cols; i++)
			{
				if (img_box_color_ROI.at<uchar>(j, i) != 0)
				{
                    ok = 1;
                    
				}
			}
		}

        if(ok == 1)
        {
            printf("box ok\n");
			status.status = 1;
            flag = 1;
            break;
        }


		imshow("img", img_box_thre);
		imshow("img_file", img_file_gray);
        imshow("img_box_color_ROI",img_box_color_ROI);

		

		if (waitKey(100) == 27)  break;
	}
    
}

int main(int argc, char** argv)
{
    ros::init(argc, argv, "camera1_node");
	ros::NodeHandle nh;

    ros::Subscriber  sub = nh.subscribe("Start_topic", 1, camera_box_callback);
	ros::Publisher 	 pub = nh.advertise<swiftpro::status>("V_Check_topic", 1);
	ros::Rate loop_rate(20);

	cap.open(0);

	if(cap.isOpened())	printf("camera open~!~~!~!!\n");

	printf("hi\n");

    //camera_box();

	while (ros::ok())	//roscore
	{
        if(flag == 1)
        {
            pub.publish(status);
            flag = 0;
            ok = 0;
        }
		ros::spinOnce();
		loop_rate.sleep();
	}

	return 0;


}